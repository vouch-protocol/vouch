"""Vouch MCP Server integration."""

from .server import VouchMCPServer, main

__all__ = ["VouchMCPServer", "main"]
