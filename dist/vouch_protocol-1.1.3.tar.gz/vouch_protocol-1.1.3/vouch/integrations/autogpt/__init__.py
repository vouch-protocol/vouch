"""Vouch AutoGPT integration."""
from .commands import sign_with_vouch, register_commands

__all__ = ["sign_with_vouch", "register_commands"]
